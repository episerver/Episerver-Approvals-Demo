//>>built
define("epi-cms/content-approval/ApprovalDefinitionStatus",{enabled:0,disabled:1,inheritEnabled:2,inheritDisabled:3});